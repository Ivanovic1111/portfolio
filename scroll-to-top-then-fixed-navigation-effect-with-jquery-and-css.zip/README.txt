A Pen created at CodePen.io. You can find this one at https://codepen.io/atelierbram/pen/dMEadR.

 Straight fork of [Scroll To Top Then Fixed Navigation Effect With jQuery and CSS](https://stanhub.com/scroll-to-top-then-fixed-navigation-effect-with-jquery-and-css-free-download/) by Stan Kostadinov